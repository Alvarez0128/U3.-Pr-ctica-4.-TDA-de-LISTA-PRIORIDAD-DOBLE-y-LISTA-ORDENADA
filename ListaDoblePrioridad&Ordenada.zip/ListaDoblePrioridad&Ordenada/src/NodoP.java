
public class NodoP {
    char valor;
    int prioridad;
    NodoP ant;
    NodoP sig;
    
    public NodoP(char v, int p){
        valor=v;
        prioridad=p;
        ant=null;
        sig=null;
    }
}
